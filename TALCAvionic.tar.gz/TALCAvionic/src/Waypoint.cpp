#include <sstream>

#include <cassert>

#include "Waypoint.hpp"

using namespace Talc::Avionique;

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::ostream& Talc::Avionique::operator<<(std::ostream& os, const Waypoint& waypoint)
{
  std::stringstream ss;
  ss << waypoint.m_id          <<
    " : " << waypoint.m_x      <<
    ", "  << waypoint.m_y      << 
    ", "  << waypoint.m_z      <<
    ", "  << waypoint.m_cap    <<
    ", "  << waypoint.m_derap  <<
    ", "  << waypoint.m_vel    <<
    ", "  << waypoint.m_v_prox <<
    ", "  << waypoint.m_d_prox << 
    ", "  << waypoint.m_wait;
  os << ss.str();
  return os;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::istream& Talc::Avionique::operator>>(std::istream& is, Waypoint& waypoint)
{
  assert( 0 );
  return is;
}

