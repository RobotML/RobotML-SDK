#include <sstream>

#include <cstring>
#include <cassert>

#include "Thumb.hpp"

using namespace Talc::Video;

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
Thumb::Thumb()
{
  //fprintf(stderr, __PRETTY_FUNCTION__" enter\n");;
  memcpy(m_data, THUMB_HEAD, m_head_len);
  //fprintf(stderr, __PRETTY_FUNCTION__" exit\n");;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
Thumb::Thumb(const Thumb &thumb)
{
  //fprintf(stderr, __PRETTY_FUNCTION__" enter\n");;
  *this = thumb;
  //fprintf(stderr, __PRETTY_FUNCTION__" exit\n");;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
Thumb::Thumb(const Image &img)
{
  //fprintf(stderr, __PRETTY_FUNCTION__" enter\n");;
  memcpy(m_data, THUMB_HEAD, m_head_len);
  *this = img;
  //fprintf(stderr, __PRETTY_FUNCTION__" exit\n");;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
const Thumb & Thumb::operator=(const Thumb &thumb)
{
  //fprintf(stderr, __PRETTY_FUNCTION__" enter\n");;
  memcpy(m_data, thumb.m_data, sizeof(m_data));
  //fprintf(stderr, __PRETTY_FUNCTION__" exit\n");;
  return *this;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
const Thumb & Thumb::operator=(const Image &img)
{
  //fprintf(stderr, __PRETTY_FUNCTION__" enter\n");;

  for(unsigned y = 0; y < m_height; y++)
    {
      unsigned Y = (y * (double)img.getHeight()) / (double)m_height;
      for(unsigned x = 0; x < m_width; x++)
        {
          unsigned X = (x * (double)img.getWidth()) / (double)m_width;
          unsigned img_offset = (Y * img.getWidth() + X) * img.getDepth();
          unsigned tmb_offset = m_head_len + (y * m_width + x) * m_depth;
          if(img.getDepth() == m_depth)
            {
              memcpy(&m_data[tmb_offset], 
                     &(img.getPixels()[img_offset]), 
                     m_depth); 
            }
          else
            {
              memset(&m_data[tmb_offset], 
                     img.getPixels()[img_offset], 
                     m_depth);
            }
        }
    }

  //fprintf(stderr, __PRETTY_FUNCTION__" exit\n");;
  return *this;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::ostream& Talc::Video::operator<<(std::ostream& os, const Thumb& thumb)
{
  std::stringstream ss;
  ss << "(" << 
    thumb.m_width << "x" <<
    thumb.m_height << "x" <<
    thumb.m_depth << ")";
  os << ss.str();
  return os;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::istream& Talc::Video::operator>>(std::istream& is, Thumb& thumb)
{
  assert( 0 );
  return is;
}

