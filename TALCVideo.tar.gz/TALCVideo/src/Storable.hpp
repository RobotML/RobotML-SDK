#ifndef __talc_fileio_Storable_hpp__
#define __talc_fileio_Storable_hpp__

#include <inttypes.h>

namespace Talc
{
  namespace Fileio
  {
    struct Storable
    {
      virtual ~Storable(void) {}
 
      /** 
       * Give the timestamp of the current data
       *
       */
      virtual double getTs(void) const
      {
        return 0;
      }

      /** 
       * Store the class in the buffer as if it was a file.
       * @param[out] buffer a pointer to the buffer.
       * @param[in]  sizeof_buffer the maximum number of bytes that we can store in buffer.
       * @param[out] file_name a pointer to the file name.
       * @param[in]  sizeof_file_name the maximum number of bytes that we can store in file_name.
       * @return     < 0 if failure, else the number of written bytes.
       */
      virtual int store(uint8_t *buffer, unsigned sizeof_buffer, char * file_name, unsigned sizeof_file_name) const
      {
        return -1;
      }

      /** 
       * Store the class in the buffer as if it was a line.
       * @param[out] buffer a pointer to the buffer.
       * @param[in]  sizeof_buffer the maximum number of bytes that we can store in buffer.
       * @param[in]  flag_first true if it's the first line.
       * @return     < 0 if failure, else the number of written bytes.
       */
      virtual int store(uint8_t *buffer, unsigned sizeof_buffer, bool flag_first) const
      {
        return -1;
      }

    };
  }
}

#endif /* __talc_fileio_Storable_hpp__ */
