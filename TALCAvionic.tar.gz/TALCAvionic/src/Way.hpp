#ifndef __talc_avionique_Way_hpp__
#define __talc_avionique_Way_hpp__

#include <iostream>

namespace Talc
{
  namespace Avionique
  {
    struct Way
    {
      unsigned m_id; 
      unsigned m_position_in_mission;
      unsigned m_nb_loops;
      unsigned m_nb_wp;
      unsigned m_first_wp_id;
    };

    std::ostream& operator<<(std::ostream& os, const Way& way);

    std::istream& operator>>(std::istream& is, Way& way);
  }
}


#endif /* __talc_avionique_Way_hpp__ */
