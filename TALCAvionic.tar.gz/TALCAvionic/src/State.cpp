#include <sstream>
#include <limits>

#include <cstdio>
#include <cassert>

#include "State.hpp"

using namespace Talc::Avionique;

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
static const unsigned state_ts_width           = 22;
static const unsigned state_time_width         = 18; 
static const unsigned state_phase_width        = 6;
static const unsigned state_wp_width           = 4;   
static const unsigned state_cpt_width          = 4;   
static const unsigned state_h_int_time_width   = 18;
static const unsigned state_h_width            = 14;    
static const unsigned state_gps_int_time_width = 18;
static const unsigned state_x_width            = 12;    
static const unsigned state_y_width            = 12;    
static const unsigned state_z_width            = 12;    
static const unsigned state_phi_width          = 12;  
static const unsigned state_theta_width        = 12;
static const unsigned state_psi_width          = 12; 
static const unsigned state_vx_width           = 12;   
static const unsigned state_vy_width           = 12;   
static const unsigned state_vz_width           = 12;   
static const unsigned state_ax_width           = 12;   
static const unsigned state_ay_width           = 12;   
static const unsigned state_az_width           = 12;   

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
const double Talc::Avionique::State::badRefInf = -std::numeric_limits<double>::max();
const double Talc::Avionique::State::badRefSup =  std::numeric_limits<double>::max();

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
State::State() :
  m_ts_ref(0),
  m_ts(0),
  m_ts_remote(0),
  m_phase(0),
  m_wp(0),
  m_cpt(0),
  m_h_int_time(std::numeric_limits<unsigned>::max()),
  m_h(0),
  m_gps_int_time(std::numeric_limits<unsigned>::max())
{
//  std::array<double, 3> zero = {{0, 0, 0}};
  double zero[3] = {0, 0, 0};
//  m_pos = zero;
//  m_att = zero;
//  m_vel = zero;
//  m_acc = zero;
  for(int i=0;i < 3;i++){
    m_pos[i] = zero[i];
    m_att[i] = zero[i];
    m_vel[i] = zero[i];
    m_acc[i] = zero[i];
  }
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
int State::store(uint8_t *buffer, unsigned sizeof_buffer, bool flag_first) const
{
  unsigned buffer_usage = 0;

  if(flag_first)
    {
      // ecriture de la premiere ligne du fichier
      int nb_printed = snprintf((char *)buffer, sizeof_buffer, 
                                "%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|%*s|\n",
                                state_ts_width           , "time(s)",
                                state_time_width         , "navtime(s)",          
                                state_phase_width        , "phase",
                                state_wp_width           , "wp",
                                state_cpt_width          , "cpt",
                                state_h_int_time_width   , "h_int_time(s)",
                                state_h_width            , "h",
                                state_gps_int_time_width , "gps_int_time(s)",
                                state_x_width            , "x", 
                                state_y_width            , "y", 
                                state_z_width            , "z", 
                                state_phi_width          , "phi",
                                state_theta_width        , "theta",
                                state_psi_width          , "psi",
                                state_vx_width           , "vx",
                                state_vy_width           , "vy",
                                state_vz_width           , "vz",
                                state_ax_width           , "ax",
                                state_ay_width           , "ay",
                                state_az_width           , "az"
                                );
      if(nb_printed < 0 || (sizeof_buffer <= (unsigned)nb_printed))
        {
          return -1;
        }
      buffer_usage += nb_printed;
      buffer += nb_printed;
      sizeof_buffer -= nb_printed;
    }

  if(m_ts)
    {
      int nb_printed = snprintf((char *)buffer, sizeof_buffer, 
                                "%*.9lf|%*.3lf|%*u|%*u|%*u|%*lf|% *lf|%*lf|% *lf|% *lf|% *lf|% *lf|% *lf|% *lf|% *lf|% *lf|% *lf|% *lf|% *lf|% *lf|\n",
                                state_ts_width           , m_ts,
                                state_time_width         , m_ts_remote,          
                                state_phase_width        , m_phase,
                                state_wp_width           , m_wp,
                                state_cpt_width          , m_cpt,
                                state_h_int_time_width   , m_h_int_time,
                                state_h_width            , m_h,
                                state_gps_int_time_width , m_gps_int_time,
                                state_x_width            , m_pos[0], 
                                state_y_width            , m_pos[1], 
                                state_z_width            , m_pos[2], 
                                state_phi_width          , m_att[0],
                                state_theta_width        , m_att[1],
                                state_psi_width          , m_att[2],
                                state_vx_width           , m_vel[0],
                                state_vy_width           , m_vel[1],
                                state_vz_width           , m_vel[2],
                                state_ax_width           , m_acc[0],
                                state_ay_width           , m_acc[1],
                                state_az_width           , m_acc[2]
                                );                        
      if(nb_printed < 0 || (sizeof_buffer <= (unsigned)nb_printed))
        {
          return -1;
        }
      buffer_usage += nb_printed;
    }
  return buffer_usage;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
int State::load(const uint8_t *buffer, unsigned sizeof_buffer, bool flag_first)
{
  if(flag_first)
    {
      return 0;
    }
  else
    {
      int nb_assigned = sscanf((const char *)buffer, 
                               "%lf|%lf|%u|%u|%u|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%lf|\n",
                               &m_ts,
                               &m_ts_remote,          
                               &m_phase,
                               &m_wp,
                               &m_cpt,
                               &m_h_int_time,
                               &m_h,
                               &m_gps_int_time,
                               &m_pos[0], 
                               &m_pos[1],
                               &m_pos[2], 
                               &m_att[0],
                               &m_att[1],
                               &m_att[2],
                               &m_vel[0],
                               &m_vel[1],
                               &m_vel[2],
                               &m_acc[0],
                               &m_acc[1],
                               &m_acc[2]
                               );

      if(nb_assigned != 19)
        {
          std::cerr << __PRETTY_FUNCTION__ << "state format not recognized (" << nb_assigned << " items read, 18 expected)" << std::endl;
          //std::cerr << (const char *)buffer << std::endl;
          return -1;
        }
    }
  return 0;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::ostream& Talc::Avionique::operator<<(std::ostream& os, const State& state)
{
  std::stringstream ss;
  std::ios_base::fmtflags old_flags = ss.setf(std::ios_base::fixed, std::ios_base::floatfield);
  ss << state.m_ts_ref << " " << state.m_ts ;
  ss.flags(old_flags);
  ss <<
    " " <<   state.m_ts_remote    <<
    " " <<   state.m_phase        <<
    " " <<   state.m_wp           << 
    " " <<   state.m_cpt          << 
    " (" <<  state.m_h_int_time   <<
    " " <<   state.m_h            <<
    ") " <<  state.m_gps_int_time <<
    " (" <<  state.m_pos[0]       <<
    ", " <<  state.m_pos[1]       <<
    ", " <<  state.m_pos[2]       << 
    ") (" << state.m_att[0]       <<
    ", " <<  state.m_att[1]       <<
    ", " <<  state.m_att[2]       <<
    ") (" << state.m_vel[0]       <<
    ", " <<  state.m_vel[1]       <<
    ", " <<  state.m_vel[2]       <<
    ") (" << state.m_acc[0]       <<
    ", " <<  state.m_acc[1]       <<
    ", " <<  state.m_acc[2]       <<
    ")";
  os << ss.str();
  return os;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::istream& Talc::Avionique::operator>>(std::istream& is, State& state)
{
  assert( 0 );
  return is;
}



