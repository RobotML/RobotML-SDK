struct png_size_t {int i;};
#define png_voidp void*
struct png_cb_free {int i;};
struct png_structp {int i;};
void* png_get_mem_ptr(png_structp x);
