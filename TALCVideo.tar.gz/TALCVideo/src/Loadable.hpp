#ifndef __talc_fileio_Loadable_hpp__
#define __talc_fileio_Loadable_hpp__

#include <inttypes.h>

namespace Talc
{
  namespace Fileio
  {
    struct Loadable
    {
      virtual ~Loadable(void) {}


      /** 
       * Give the timestamp of the current data
       *
       */
      virtual double getTs(void) const
      {
        return 0;
      }

      /** 
       * Load the class from the buffer as if it was a file.
       *
       */
      virtual int load(const uint8_t *buffer, unsigned sizeof_buffer, const char * file_name, unsigned sizeof_file_name)
      {
        return -1;
      }

      /** 
       * Load the class from the buffer as if it was a line.
       *
       */
      virtual int load(const uint8_t *buffer, unsigned sizeof_buffer, bool flag_first)
      {
        return -1;
      }

    };
  }
}

#endif /* __talc_fileio_Loadable_hpp__ */
