#include <rtt/TaskContext.hpp>
#include <rtt/Port.hpp>
#include <geometry_msgs/Point.h>
#include <ocl/Component.hpp>
#include <std_msgs/String.h>
#include <sensor_msgs/NavSatFix.h>
#include <numeric>
#include <vector>
#include <cstring>
#include <string>

#include "State.hpp"
#include "ObcInterface.hpp"
#include "ObcImplROS.hpp"

using namespace std;
using namespace RTT;

class TALCAvionic : public RTT::TaskContext {
private:  
//  ROS to Morse side
  InputPort<std_msgs::String> inport_gyro;
  InputPort<sensor_msgs::NavSatFix> inport_gps;
  OutputPort<geometry_msgs::Point> outport;
// OROCOS side
  RTT::OutputPort<Talc::Avionique::State> m_state_port;

  Talc::Avionique::State m_state;

  unsigned int oldwpid;
  vector<geometry_msgs::Point> route;
  bool wp_reached;
  int curent_wp;
  double x, y, z;
  Talc::Avionique::ObcImplROS * interface_implementation; 

public:
  TALCAvionic(const std::string& name):
    TaskContext(name),
    inport_gyro("gyroscope_in"),
    inport_gps("gps_in"),
    outport("point_out")
  {
    ports()->addPort(inport_gyro);
    ports()->addPort(inport_gps);
    ports()->addPort(outport);
    addPort("state"    , m_state_port).doc("Output state.");
    Talc::Avionique::ObcInterface * m_itf(new Talc::Avionique::ObcImplROS);
    interface_implementation = (Talc::Avionique::ObcImplROS *) m_itf;

  // OperationInterface
    addOperation("getInterfaceName", &Talc::Avionique::ObcInterface::getInterfaceName                          , RTT::ClientThread).doc("Get interface name"                                      );
    addOperation("getState"        , &Talc::Avionique::ObcInterface::getState        , interface_implementation, RTT::ClientThread).doc("Get state at exact time (interpolation or extrapolation)").arg("State", "the state").arg("Date", "the date in seconds (or -1 for the last state)").arg("Ref", "an index that tell wich state has been choosen.");
    addOperation("setPhase"        , &Talc::Avionique::ObcInterface::setPhase        , interface_implementation, RTT::ClientThread).doc("Change flight phase"                                     ).arg("Phase", "the requested phase");
    addOperation("setPhaseStr"     , &Talc::Avionique::ObcInterface::setPhaseStr     , interface_implementation, RTT::ClientThread).doc("Change flight phase (literal)"                           ).arg("Phase", "the requested phase name (Stationary, Route, Goal, Tracking)");
    addOperation("setPhaseDescente", &Talc::Avionique::ObcInterface::setPhaseDescente, interface_implementation, RTT::ClientThread).doc("Change flight phase to descente."                        ).arg("altitude", "the requested altitude in meters.");
    addOperation("getPhase"        , &Talc::Avionique::ObcInterface::getPhase        , interface_implementation, RTT::ClientThread).doc("Return the current flight phase"                         );
    addOperation("getPhaseStr"     , &Talc::Avionique::ObcInterface::getPhaseStr     , interface_implementation, RTT::ClientThread).doc("Return the current flight phase (literal)"               );
    addOperation("move"            , &Talc::Avionique::ObcInterface::move            , interface_implementation, RTT::ClientThread).doc("Move"                                                    );
    addOperation("gotou"           , &Talc::Avionique::ObcInterface::gotou           , interface_implementation, RTT::ClientThread).doc("Goto"                                                    );
    addOperation("track"           , &Talc::Avionique::ObcInterface::track           , interface_implementation, RTT::ClientThread).doc("Send tracking commands"                                  ).arg("Vx" , "North Velocity (inertial frame)").arg("Vy", "East Velocity (inertial frame)").arg("Z", "Altitude").arg("Psi", "Heading (yaw angle)");
    addOperation("altitude"        , &Talc::Avionique::ObcInterface::altitude        , interface_implementation, RTT::ClientThread).doc("Send altitude commands"                                  ).arg("h" , "altitude in meters").arg("en", "confirmation flag");
    addOperation("waypointAdd"     , &Talc::Avionique::ObcInterface::waypointAdd     , interface_implementation, RTT::ClientThread).doc("Add a waypoint"                                          ).arg("wp", "waypoint description");
    addOperation("waypointDel"     , &Talc::Avionique::ObcInterface::waypointDel     , interface_implementation, RTT::ClientThread).doc("Delete a waypoint"                                       ).arg("wp", "waypoint description");
    addOperation("wayAdd"          , &Talc::Avionique::ObcInterface::wayAdd          , interface_implementation, RTT::ClientThread).doc("Add a way"                                               ).arg("w", "way description");
    addOperation("wayDel"          , &Talc::Avionique::ObcInterface::wayDel          , interface_implementation, RTT::ClientThread).doc("Delete a way"                                            ).arg("w", "way description");
    addOperation("wayPush"         , &Talc::Avionique::ObcInterface::wayPush         , interface_implementation, RTT::ClientThread).doc("Push a way"                                              ).arg("w", "way description");
    addOperation("wayPop"          , &Talc::Avionique::ObcInterface::wayPop          , interface_implementation, RTT::ClientThread).doc("Pop way"                                                 );
    addOperation("obstacleAdd"     , &Talc::Avionique::ObcInterface::obstacleAdd     , interface_implementation, RTT::ClientThread).doc("Add an obstacle"                                         ).arg("obst", "obstacle description");
    addOperation("obstacleDel"     , &Talc::Avionique::ObcInterface::obstacleDel     , interface_implementation, RTT::ClientThread).doc("Delete an obstacle"                                      );
    addOperation("setObj"          , &Talc::Avionique::ObcInterface::setObj          , interface_implementation, RTT::ClientThread).doc("Set objective"                                           ).arg("w", "way description").arg("wp", "waypoint description");
    addOperation("quickWaypointDel", &Talc::Avionique::ObcInterface::quickWaypointDel, interface_implementation, RTT::ClientThread).doc("Delete a waypoint according to its id"                   ).arg("wp_id", "waypoint id");
    addOperation("quickSetObj"     , &Talc::Avionique::ObcInterface::quickSetObj     , interface_implementation, RTT::ClientThread).doc("Set objective according to its id"                       ).arg("w_id", "way id").arg("wp_id", "waypoint id");

    addOperation("getMinDt"        , &Talc::Avionique::ObcInterface::getMinDt        , interface_implementation, RTT::ClientThread).doc("Get min integration time"                                );
    addOperation("getMaxV"         , &Talc::Avionique::ObcInterface::getMaxV         , interface_implementation, RTT::ClientThread).doc("Get max speed"                                           );
    addOperation("getMaxA"         , &Talc::Avionique::ObcInterface::getMaxA         , interface_implementation, RTT::ClientThread).doc("Get max acceleration"                                    );

    wp_reached = true;
    curent_wp = -1;
    oldwpid = 50;
  }
  ~TALCAvionic()
 {
    route.clear();
 }
private:
  void updateHook() {
    log(Info)<<"TALCAvionic : updateHook"<<endlog();
    log(Info)<<"m_wp_id = "<<interface_implementation->m_wp_id<<endlog();
    if (interface_implementation->m_wp_id != oldwpid) {
      log(Info)<<interface_implementation->wplist.size()<<" new wps received"<<endlog();
      oldwpid = interface_implementation->m_wp_id;
      geometry_msgs::Point* pt = new geometry_msgs::Point();
      for(unsigned int i=0;i < interface_implementation->wplist.size();i++) {
	pt->x = interface_implementation->wplist.at(i).m_x;
	pt->y = interface_implementation->wplist.at(i).m_y;
	pt->z = interface_implementation->wplist.at(i).m_z;
        route.push_back(*pt);
      }
      interface_implementation->wplist.clear();
      delete pt;
      if(curent_wp == -1) {
	curent_wp = 0;
        wp_reached = false;
        outport.write(route[0]);
      }
    }
    std_msgs::String msg_gyro;
    if (NewData == inport_gyro.read(msg_gyro)) {
      log(Info)<<"Gyro: "<<msg_gyro.data<<endlog(); }
    sensor_msgs::NavSatFix msg_gps;
    if (NewData == inport_gps.read(msg_gps)) {
      log(Info)<<"GPS: "<<endlog();
 //     char *cstr = new char [msg_gps.data.size()+1];
 //     strcpy(cstr,msg_gps.data.c_str());
 //     sscanf(cstr,"%lf, %lf, %lf",&x,&y,&z);
      x = (double)msg_gps.latitude;
      y = (double)msg_gps.longitude;
      z = (double)msg_gps.altitude;
      if(wp_reached == false) {
        double dist2 = (x-route[curent_wp].x)*(x-route[curent_wp].x) + (y-route[curent_wp].y)*(y-route[curent_wp].y) + (z-route[curent_wp].z)*(z-route[curent_wp].z);
        log(Info)<<"x = "<<x<<" y = "<<y<<" z = "<<z<<"dist2 = "<<dist2<<endlog();
        if(dist2 < 0.5) wp_reached = true;
      }
      m_state.m_pos[0] = x;
      m_state.m_pos[1] = y;
      m_state.m_pos[2] = z;
      m_state_port.write(m_state);
      log(Info)<<"State writen: "<<endlog();
    }
    if (wp_reached && (curent_wp !=(route.size()-1))) {
      wp_reached = false;
      curent_wp++;
      outport.write(route[curent_wp]);   
    }
  }
};

ORO_CREATE_COMPONENT(TALCAvionic)
