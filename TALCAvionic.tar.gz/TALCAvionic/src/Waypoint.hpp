#ifndef __talc_avionique_Waypoint_hpp__
#define __talc_avionique_Waypoint_hpp__

#include <iostream>

namespace Talc
{
  namespace Avionique
  {
    struct Waypoint
    {
      unsigned m_id;      
      double   m_x;      // position x in meters (positive north)
      double   m_y;      // position y in meters (positive east)
      double   m_z;      // position z in meters (positive down)
      double   m_cap;    // direction en radian par rapport au nord selon laquelle on arrive sur le point 
      double   m_derap;  // direction en radian par rapport au cap selon laquelle le nez de l'helico pointe psi = cap - derap
      double   m_vel;    // vitesse de passage sur le point (si zero voir parametre wait) en m/s
      double   m_v_prox; // vitesse d'approche (sur la trajectoire pour aller au point) en m/s
      double   m_d_prox; // distance en metre dans laquelle on se considere sur le point (2m c'est bien)
      double   m_wait;   // si m_vel == 0 temps d'attente en secondes sur le point (attention au moins 1 ou 2 secondes)
    };

    std::ostream& operator<<(std::ostream& os, const Waypoint& waypoint);

    std::istream& operator>>(std::istream& is, Waypoint& waypoint);

  }
}

#endif /* __talc_avionique_Waypoint_hpp__ */
