#ifndef __talc_avionique_ObcInterface_hpp__
#define __talc_avionique_ObcInterface_hpp__

#include <string>
// #include <array>

#include "Phase.hpp"
#include "State.hpp"
#include "Waypoint.hpp"
#include "Way.hpp"
#include "Obstacle.hpp"
  
namespace Talc
{
  namespace Avionique
  {
    struct ObcInterface
    {
      virtual ~ObcInterface(void) {} 
      
      /////////////////////

      static std::string getInterfaceName(void)
      { 
        return "Talc::Avionique::Obc"; 
      }

      /////////////////////

      virtual bool init(State &state) = 0;

      virtual void kill(void) = 0;

      virtual bool start(void) = 0;

      virtual void stop(void) = 0;

      virtual int capture(State &state) = 0;

      virtual bool breakCapture(void) = 0;

      /////////////////////

      std::string            m_rx_path;         /**< Path to the rx link */
      std::string            m_tx_path;         /**< Path to the tx link */
 //     std::array<double, 3>  m_origin;          /**< Origin of the world frame in WGS84 GPS coords + altitude */
      double m_origin[3];
      bool                   m_enable_tx;       /**< Enable the tx link */
      bool                   m_have_gps;        /**< Emulation de la perte de GPS */
      bool                   m_manage_wp_ids;   /**< Let the implementation manage waypoints ids */
      unsigned               m_wp_id_min;
      unsigned               m_wp_id_max;
      bool                   m_manage_w_ids;    /**< Let the implementation manage ways ids */
      unsigned               m_w_id_min;
      unsigned               m_w_id_max;
      bool                   m_manage_obst_ids; /**< Let the implementation manage obstacles ids */
      unsigned               m_obst_id_min;
      unsigned               m_obst_id_max;

      /////////////////////

      virtual bool logState(const State& state) = 0;

      virtual bool getState(State& state, double date = -1) const = 0;

      virtual bool setPhase(unsigned phase) = 0;

      virtual bool setPhaseStr(const std::string& str) = 0;

      /**
       * @param[in] altitude in meters (positive up, from ground)
       */
      virtual bool setPhaseDescente(double altitude) = 0;

      virtual unsigned getPhase(void) const = 0;

      virtual std::string getPhaseStr(void) const = 0;

      /**
       * @param[in] x in meters (positive north)
       * @param[in] y in meters (positive east)
       * @param[in] z in meters (positive down)
       * @param[in] psi in radian
       */
      virtual bool move(double x, double y, double z, double psi) = 0;

      /**
       * @param[in] x in meters (positive north)
       * @param[in] y in meters (positive east)
       * @param[in] z in meters (positive down)
       * @param[in] psi in radian
       */
      virtual bool gotou(double x, double y, double z, double psi) = 0;

      /**
       * @param[in] vx in meters/s (positive north)
       * @param[in] vy in meters/s (positive east)
       * @param[in] z in meters (positive down)
       * @param[in] psi in radian
       */
      virtual bool track(double vx, double vy, double z, double psi) = 0;

      /**
       * @param[in] altitude in meters (positive up, from ground)
       */
      virtual bool altitude(double altitude, bool enable) = 0;

      virtual bool waypointAdd(Waypoint& wp) = 0;

      virtual bool waypointDel(const Waypoint& wp) = 0;

      virtual bool wayAdd(Way& w) = 0;

      virtual bool wayDel(const Way& w) = 0;

      virtual bool wayPush(Way& w) = 0;

      virtual bool wayPop(void) = 0;

      virtual bool obstacleAdd(Obstacle& obst) = 0;

      virtual bool obstacleDel(const Obstacle& obst) = 0;

      virtual bool setObj(const Way& w, const Waypoint& wp) = 0;

      virtual bool quickWaypointDel(unsigned wp_id) = 0;

      virtual bool quickSetObj(unsigned w_id, unsigned wp_id) = 0;

      /////////////////////

      virtual double getMinDt(void) = 0;

      virtual double getMaxV(void) = 0;

      virtual double getMaxA(void) = 0;

    };
  }
}

#endif /* define __talc_avionique_ObcInterface_hpp__ */
