#ifndef __talc_avionique_State_hpp__
#define __talc_avionique_State_hpp__

#include <iostream>
// #include <array>

#include "../../TALCVideo/src/Storable.hpp"
#include "../../TALCVideo/src/Loadable.hpp"

namespace Talc
{
  namespace Avionique
  {
    struct State : public Fileio::Storable, public Fileio::Loadable
    {
      double                m_ts_ref;       // timestamp de l'etat de reference sur lequel cet etat a ete genere (si == m_ts copie, si < m_ts interpol, si > m_ts extrapol)
      double                m_ts;           // timestamp referentiel epoque unix en secondes
      double                m_ts_remote;    // timestamp referenciel avionique en secondes
      unsigned              m_phase;        // numero de phase    (meme valeur que celle envoye par la nav)
      unsigned              m_wp;           // numero de waypoint (meme valeur que celle envoye par la nav)
      unsigned              m_cpt;          // compteur de trame
      double                m_h_int_time;   // temps d'integration de h : 0 altimetre disponible, sinon temps d'integration en secondes
      double                m_h;            // altitude barometre (par rapport au niveau de la mer)
      double                m_gps_int_time; // temps d'integration gps : 0 gps disponible, sinon temps d'integration en secondes
      //std::array<double, 3> m_pos;          // position (x, y, z) (repere direct) (l'axe des z est inverse (pointe vers le bas) par rapport a celui envoye par la nav)
      double m_pos[3];
      //std::array<double, 3> m_att;          // attitude (phi (3ieme rot autour de X), theta (2ieme rot autour de Y), psi (1iere rot autour de Z)) en radian
      double m_att[3];
      //std::array<double, 3> m_vel;          // velocity (vx, vy, vz) en m/s
      double m_vel[3];
      //std::array<double, 3> m_acc;          // acceleration (ax, ay, az) en m/ss
      double m_acc[3];

      State(void);

      static const double badRefInf;
      static const double badRefSup;
      bool badRef(void) const
      {
        return (m_ts_ref == badRefInf) || (m_ts_ref == badRefSup);
      }
      
      double getTs(void) const
      {
        return m_ts;
      }

      int store(uint8_t *buffer, unsigned sizeof_buffer, bool flag_first) const;

      int load(const uint8_t *buffer, unsigned sizeof_buffer, bool flag_first);

    };

    std::ostream& operator<<(std::ostream& os, const State& state);

    std::istream& operator>>(std::istream& is, State& state);

  }
}

#endif /* __talc_avionique_State_hpp__ */
