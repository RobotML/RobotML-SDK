#ifndef __talc_avionique_Phase_hpp__
#define __talc_avionique_Phase_hpp__

#include <string>

namespace Talc
{
  namespace Avionique
  {
    struct Phase
    {
      // L'idee ici, est de ne pas etre dependant du protocole
      // Mais d'un autre cote, pour faciliter la relecture des logs,
      // il faudrait que les valeurs de la phase soient identiques a 
      // celles de la nav.
      // Donc en compromis on s'interdit d'include Protocol.hpp mais il faut garantir 
      // la coherence de ces valeurs avec celles donnees dans Protocol.hpp
      static const unsigned Initialisation = 0x00;
      static const unsigned Decollage      = 0x01;
      static const unsigned Statio         = 0x02;
      static const unsigned Route          = 0x03;
      static const unsigned Atterissage    = 0x04;
      static const unsigned Manuel         = 0x05;
      static const unsigned Recuperation   = 0x06;
      static const unsigned Crash          = 0x07;
      static const unsigned Retourbase     = 0x08;
      static const unsigned Arret          = 0x09;
      static const unsigned StatioObjectif = 0x0B; // 11
      static const unsigned StatioBase     = 0x0A;
      static const unsigned StatioPilote   = 0x12;
      static const unsigned Descente       = 0x15; // 21
      static const unsigned Tracking       = 0x16; // 22
      static const unsigned Croisiere      = 0x17; // 23

      /** 
       * Donne la phase sous forme d'entier en fonction de chaine
       */
      static int stringToPhase(const std::string& str);

      /** 
       * Donne la phase sous forme de chaine en fonction d'un entier
       */
      static std::string phaseToString(int phase);
    };
  }
}

#endif /* __talc_avionique_Phase_hpp__ */
