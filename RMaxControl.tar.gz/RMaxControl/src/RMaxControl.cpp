#include <rtt/TaskContext.hpp>
#include <rtt/Port.hpp>
#include <ocl/Component.hpp>
#include <numeric>
#include <vector>
#include <cstring>
#include <string>

#include "../../TALCAvionic/src/State.hpp"
#include "../../TALCAvionic/src/ObcInterface.hpp"
#include "../../TALCVideo/src/Image.hpp"

using namespace std;
using namespace RTT;

class RMaxControl : public RTT::TaskContext {
private:  
//  OutputPort<geometry_msgs::Point> outport;
  InputPort<Talc::Avionique::State> inport_state;
  InputPort<Talc::Video::Image> inport_image;
/* Pointer to the Avionique::Obc getState op */
  RTT::OperationCaller<bool(Talc::Avionique::State&, double) > m_get_state_op;
  RTT::SendHandle     <bool(Talc::Avionique::State&, double) > m_get_state_handle;
/* Pointer to the Avionique::Obc setPhase op */
  RTT::OperationCaller<bool(unsigned) >                  m_set_phase_op;
  RTT::SendHandle     <bool(unsigned) >                  m_set_phase_handle;
/* Pointer to the Avionique::Obc  op */
  RTT::OperationCaller<bool(Talc::Avionique::Waypoint&) >      m_waypoint_add_op;
  RTT::SendHandle     <bool(Talc::Avionique::Waypoint&) >      m_waypoint_add_handle;
/* Pointer to the Avionique::Obc  op */
  RTT::OperationCaller<bool(Talc::Avionique::Waypoint&) >      m_waypoint_del_op;
  RTT::SendHandle     <bool(Talc::Avionique::Waypoint&) >      m_waypoint_del_handle;
/* Pointer to the Avionique::Obc  op */
  RTT::OperationCaller<bool(Talc::Avionique::Way&) >           m_way_push_op;
  RTT::SendHandle     <bool(Talc::Avionique::Way&) >           m_way_push_handle;
/* Pointer to the Avionique::Obc  op */
  RTT::OperationCaller<bool(void) >                      m_way_pop_op;
  RTT::SendHandle     <bool(void) >                      m_way_pop_handle;

  double minvar;
  double x, y, z;
  double argminx, argminy;
  bool landing_site_found;
  bool first_time;

public:
  RMaxControl(const std::string& name):
    TaskContext(name),
    inport_state("state_in"),
    inport_image("image_in")
  {
    ports()->addPort(inport_image);
    ports()->addPort(inport_state);
    first_time = true;
    minvar = 10000000000000000.0;
    landing_site_found = false;
  }
  ~RMaxControl()
 {
 }
private:
  bool configureHook(){
  log(Info)<<"RMaxControl : configureHook"<<endlog();
  bool obc_ops_found = false;
  RTT::TaskContext::PeerList peers = getPeerList();
  for(RTT::TaskContext::PeerList::const_iterator i = peers.begin(); i != peers.end(); ++i) 
    {
      log(Info)<<"RMaxControl : configureHook : Peer"<<endlog();
      RTT::TaskContext * peer = getPeer(*i);
      RTT::OperationCaller<std::string(void)> getInterfaceName;
      getInterfaceName = peer->getOperation("getInterfaceName");
      if(getInterfaceName.ready())
        {
          if(getInterfaceName() == Talc::Avionique::ObcInterface::getInterfaceName())
            {
              log(Info) << "binded to 'setPhase', 'waypointAdd', 'waypointDel', 'wayPush', 'wayPop' operations of avionic " << *i << endlog();
              m_get_state_op    = peer->getOperation("getState"   );
              m_set_phase_op    = peer->getOperation("setPhase"   );
              m_waypoint_add_op = peer->getOperation("waypointAdd");
              m_waypoint_del_op = peer->getOperation("waypointDel");
              m_way_push_op     = peer->getOperation("wayPush"    );
              m_way_pop_op      = peer->getOperation("wayPop"     );
          
              obc_ops_found = true;
            }
        }
    }
  if(!obc_ops_found)
    {
      log(Error) << "No peer own 'setPhase', 'waypointAdd', 'waypointDel', 'wayPush', 'wayPop' ops !" << endlog();
      return false;
    }
  return true;
  }
  void updateHook() {
    Talc::Avionique::Waypoint wp;
    log(Info)<<"RMaxControl : updateHook"<<endlog();
    if(first_time) {
    wp.m_x = 20.0;
    wp.m_y = 20.0;
    wp.m_z = 10.0;
    if(!m_waypoint_add_op(wp))
      {
        log(Error) << "m_waypoint_add_op(" << wp << ") failed" << endlog();
      }
    else
      {
        log(Info) << "m_waypoint_add_op(" << wp << ")" << RTT::Logger::endl;
      }
    wp.m_x = -20.0;
    wp.m_y = 20.0;
    wp.m_z = 10.0;
    if(!m_waypoint_add_op(wp))
      {
        log(Error) << "m_waypoint_add_op(" << wp << ") failed" << endlog();
      }
    else
      {
        log(Info) << "m_waypoint_add_op(" << wp << ")" << RTT::Logger::endl;
      }
    wp.m_x = -20.0;
    wp.m_y = -20.0;
    wp.m_z = 10.0;
    if(!m_waypoint_add_op(wp))
      {
        log(Error) << "m_waypoint_add_op(" << wp << ") failed" << endlog();
      }
    else
      {
        log(Info) << "m_waypoint_add_op(" << wp << ")" << RTT::Logger::endl;
      }

    wp.m_x = 20.0;
    wp.m_y = -20.0;
    wp.m_z = 10.0;
    if(!m_waypoint_add_op(wp))
      {
        log(Error) << "m_waypoint_add_op(" << wp << ") failed" << endlog();
      }
    else
      {
        log(Info) << "m_waypoint_add_op(" << wp << ")" << RTT::Logger::endl;
      }
    first_time = false;
    }

    Talc::Avionique::State msg_state;
    if(NewData == inport_state.read(msg_state)){
      log(Info)<<"State: "<<endlog();
      x = msg_state.m_pos[0];
      y = msg_state.m_pos[1];
      z = msg_state.m_pos[2];
      log(Info)<<"x = "<<x<<" y = "<<y<<" z = "<<z<<endlog();
      if(landing_site_found == false) {
        double dist2 = (x-20.0)*(x-20.0) + (y+20.0)*(y+20.0) + (z-10.0)*(z-10.0);
        log(Info)<<"dist2 = "<<dist2<<endlog();
        if((dist2 < 0.5)&&(!first_time)) {
          landing_site_found = true;
          wp.m_x = argminx;
          wp.m_y = argminy;
          wp.m_z = 10.0;
          if(!m_waypoint_add_op(wp))
            {
            log(Error) << "m_waypoint_add_op(" << wp << ") failed" << endlog();
            }
          else
            {
            log(Info) << "m_waypoint_add_op(" << wp << ")" << RTT::Logger::endl;
            }
          wp.m_x = argminx;
          wp.m_y = argminy;
          wp.m_z = 2.0;
          if(!m_waypoint_add_op(wp))
            {
            log(Error) << "m_waypoint_add_op(" << wp << ") failed" << endlog();
            }
          else
            {
            log(Info) << "m_waypoint_add_op(" << wp << ")" << RTT::Logger::endl;
            }
          }
        }
      }
    Talc::Video::Image msg_image_talc;
    if(NewData == inport_image.read(msg_image_talc)){
      log(Info)<<"Image TALC height: "<< msg_image_talc.getHeight() <<", width:"<<msg_image_talc.getWidth()<<endlog();
      double sumr = 0.0;
      double sumg = 0.0;
      double sumb = 0.0;
      double sumr2 = 0.0;
      double sumg2 = 0.0;
      double sumb2 = 0.0;
// Use image data
      unsigned char * data = msg_image_talc.getPixels();
      for(unsigned int i = 0; i < msg_image_talc.getHeight(); i++) {
        for(unsigned int j = 0; j < msg_image_talc.getWidth(); j++) {
          int k = i*msg_image_talc.getHeight() + j;
          int r = (int)data[3*k];
          int g = (int)data[3*k+1];
          int b = (int)data[3*k+2];
          sumr += (double)r; sumr2 += (double)r*(double)r;
          sumg += (double)g; sumg2 += (double)g*(double)g;
          sumb += (double)b; sumb2 += (double)b*(double)b;
          //log(Info)<<"["<<i<<","<<j<<"] R"<<r<<" G "<<g<<" B "<<b<<endlog();
        }
      }
      double meanr = sumr / (msg_image_talc.getHeight()*msg_image_talc.getWidth());
      double meang = sumg / (msg_image_talc.getHeight()*msg_image_talc.getWidth());
      double meanb = sumb / (msg_image_talc.getHeight()*msg_image_talc.getWidth());
      double varr = sumr2 / (msg_image_talc.getHeight()*msg_image_talc.getWidth()) - meanr*meanr;
      double varg = sumg2 / (msg_image_talc.getHeight()*msg_image_talc.getWidth()) - meang*meang;
      double varb = sumb2 / (msg_image_talc.getHeight()*msg_image_talc.getWidth()) - meanb*meanb;
      double vartot = varr+varb+varg;
      if(vartot < minvar) {
        minvar = vartot;
        argminx = x;
        argminy = y;
      }
      log(Info)<<"Image TALC total variance "<<vartot<<" optimum "<<minvar<<" for "<<argminx<<" "<<argminy<<endlog();
    }
  }
};

ORO_CREATE_COMPONENT(RMaxControl)
