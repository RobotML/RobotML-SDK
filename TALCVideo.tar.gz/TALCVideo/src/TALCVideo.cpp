#include <rtt/TaskContext.hpp>
#include <rtt/Port.hpp>
#include <ocl/Component.hpp>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>
#include "Image.hpp"
#include "Thumb.hpp"

using namespace std;
using namespace RTT;

class TALCVideo : public RTT::TaskContext {
private:
// ROS to MORSE side
  InputPort<sensor_msgs::Image> inport_image;
  InputPort<sensor_msgs::CameraInfo> inport_info;
// OROCOS side
  RTT::OutputPort<Talc::Video::Image>  m_image_port;
  RTT::OutputPort<Talc::Video::Thumb>  m_thumb_port;
  Talc::Video::Image m_image;

public:
  TALCVideo(const std::string& name):
    TaskContext(name),
    inport_image("image_in"),
    inport_info("camera_info_in")
  {
    ports()->addPort(inport_image);
    ports()->addPort(inport_info);
    addPort     ("image"            , m_image_port).doc("Output image." );
    addPort     ("thumb"            , m_thumb_port).doc("Output thumb." );
  }
  ~TALCVideo()
 {
 }
private:
  void updateHook() {
    log(Info)<<"TALCVideo : updateHook"<<endlog();
    sensor_msgs::CameraInfo msg_camera_info;
    if (NewData == inport_info.read(msg_camera_info)) {
      log(Info)<<"CameraInfo: "<<endlog(); }
    sensor_msgs::Image msg_image;
    if (NewData == inport_image.read(msg_image)) {
      log(Info)<<"ROS Image height:"<<msg_image.height<<", width:"<<msg_image.width<<endlog();
      unsigned char data[4*msg_image.height*msg_image.width];
      int index = 0;
      for(unsigned int i = 0; i < msg_image.height; i++) {
        for(unsigned int j = 0; j < msg_image.width; j++) {
          // conversion from ROS r,g,b,a to TALC r,g,b
          int k = i*msg_image.height + j;
// r
          data[index] = msg_image.data[4*k];
          index++;
// g
          data[index] = msg_image.data[4*k+1];
          index++;
// b
          data[index] = msg_image.data[4*k+2];
          index++;
        }
      }
      m_image.init(0.0,msg_image.width,msg_image.height,true,data);
      m_image_port.write(m_image);
 //     m_thumb_port.write(m_image);
     }
  }
};

ORO_CREATE_COMPONENT(TALCVideo)
