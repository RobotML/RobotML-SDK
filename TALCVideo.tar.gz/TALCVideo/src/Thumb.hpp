#ifndef __talc_video_Thumb_hpp__
#define __talc_video_Thumb_hpp__

#include <iostream>

#include "Image.hpp"

namespace Talc
{
  namespace Video
  {

    struct Thumb
    {
      /** A thumbnail is a binary portable pixmap (PPM) */ 
#define THUMB_HEAD "P6 320 240 255\n"
      static const unsigned m_head_len = sizeof(THUMB_HEAD) - 1;
      static const unsigned m_width    = 320;
      static const unsigned m_height   = 240;
      static const unsigned m_depth    =   3;

      unsigned char m_data[m_head_len + m_width * m_height * m_depth];

      /**
       * Construct a thumbnail.
       */
      Thumb();

      /**
       * Construct a thumbnail from an other thumbnail.
       */
      Thumb(const Thumb &thumb);

      /**
       * Construct a thumbnail from an other image.
       */
      Thumb(const Image &img);

      /**
       * Copy a thumbnail from an other thumbnail.
       */
      const Thumb & operator=(const Thumb &thumb);

      /**
       * Copy a thumbnail from an other image.
       */
      const Thumb & operator=(const Image &img);

    } ;

    std::ostream& operator<<(std::ostream& os, const Thumb& thumb);

    std::istream& operator>>(std::istream& is, Thumb& thumb);

  }
}

#endif /* __talc_video_Thumb_hpp__ */
