#ifndef __talc_video_Image_hpp__
#define __talc_video_Image_hpp__

#include <iostream>

#include "Storable.hpp"
#include "Loadable.hpp"

namespace Talc
{
  namespace Video
  {
    class Image : public Fileio::Storable, public Fileio::Loadable
    {
 
    public :
    
      /**
       * Construct an image. If alloc is true, the image
       * will alloc his data.
       */
      Image(void);

      /**
       * Construct an image from an other image.
       */
      Image(const Image &img);

      /**
       *
       */
      ~Image(void);

      /**
       * Copy an image from an other image.
       */
      const Image & operator=(const Image &img);

      void init(double ts, unsigned width, unsigned height, bool color, const unsigned char *data = 0);

      double getTs(void) const
      {
        return m_ts;
      }

      unsigned getWidth(void) const 
      {
        return m_width;
      }

      unsigned getHeight(void) const 
      {
        return m_height;
      }

      unsigned getColor(void) const 
      {
        return m_color;
      }

      unsigned getDepth(void) const 
      {
        return m_color?3:1;
      }

      unsigned char * const * getRows(void) const
      {
        return m_rows;
      }

      unsigned char * * getRows(void)
      {
        return m_rows;
      }

      unsigned char *getPixels(void) const
      {
        return m_pixels;
      }

      unsigned char *getPixels(void)
      {
        return m_pixels;
      }

      unsigned nbPixels(void) const  
      {
        return getWidth() * getHeight() * getDepth(); 
      }

      unsigned sizeofPixels(void) const  
      {
        return nbPixels() * sizeof(m_pixels[0]); 
      }

      unsigned char *getPnm(void)
      {
        return m_pnm_image;
      }

      unsigned char *getPnm(void) const
      {
        return m_pnm_image;
      }

      unsigned sizeofPnm(void) const  
      {
        return m_pnm_image_header_size + sizeofPixels(); 
      }

      int store(uint8_t *buffer, unsigned sizeof_buffer, char * file_name, unsigned sizeof_file_name) const;

      int load(const uint8_t *buffer, unsigned sizeof_buffer, const char * file_name, unsigned sizeof_file_name);

      int m_compression_for_logging;

    private:

      double             m_ts;
      unsigned           m_width;
      unsigned           m_height;
      bool               m_color;
      unsigned char *    m_pnm_image; /**< Internaly, we use a pnm representation */
      unsigned char *    m_pixels;    /**< For ease of use we provide a direct access to pixels */
      unsigned char **   m_rows;      /**< And a per/row representation for png functions */

      // space required for storing pnm header
      static const unsigned   m_pnm_image_header_size;

      // temporary storage for compression
      mutable unsigned char * m_libpng_heap_buffer;
      static const unsigned   m_libpng_heap_buffer_size;

    };

    std::ostream& operator<<(std::ostream& os, const Image& img);

    std::istream& operator>>(std::istream& is, Image& img);

  }

}

#endif /* __talc_video_Image_hpp__ */
