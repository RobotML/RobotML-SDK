#include <sstream>

#include <cstdio>
#include <cstring>
#include <cassert>

// pour png
#include <png.h>
// pour zlib (Z_BEST Z_FAST etc.)
#include <zlib.h>


#include "Image.hpp"
#include <stdlib.h>

using namespace Talc::Video;

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
const unsigned Talc::Video::Image::m_pnm_image_header_size = 32;
const unsigned Talc::Video::Image::m_libpng_heap_buffer_size = 0x1000000;

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
Image::Image(void) :
  m_compression_for_logging(false),
  m_ts(0),
  m_width(0),
  m_height(0),
  m_color(false),
  m_pnm_image(0),
  m_pixels(0),
  m_rows(0),
  m_libpng_heap_buffer(0)
{
  //std::cerr << __PRETTY_FUNCTION__ << " enter" << std::endl;
  //std::cerr << __PRETTY_FUNCTION__ << " exit"  << std::endl;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
Image::Image(const Image &img) :
  m_compression_for_logging(false),
  m_ts(0),
  m_width(0),
  m_height(0),
  m_color(false),
  m_pnm_image(0),
  m_pixels(0),
  m_rows(0),
  m_libpng_heap_buffer(0)
{
  //std::cerr << __PRETTY_FUNCTION__ << " enter" << std::endl;
  *this = img;
  //std::cerr << __PRETTY_FUNCTION__ << " exit"  << std::endl;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
Image::~Image()
{
  //std::cerr << __PRETTY_FUNCTION__ << " enter" << std::endl;
  if(m_pnm_image)
    {
      delete[] m_pnm_image;
    }
  if(m_rows)
    {
      delete [] m_rows;
    }
  if(m_libpng_heap_buffer)
    {
      delete [] m_libpng_heap_buffer;
    }
  //std::cerr << __PRETTY_FUNCTION__ << " exit"  << std::endl;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
const Image & Image::operator=(const Image &img)
{
  //std::cerr << __PRETTY_FUNCTION__ << " enter" << std::endl;
  if(this != &img)
    {
      init(img.m_ts, img.m_width, img.m_height, img.m_color, img.m_pixels);
      m_compression_for_logging = img.m_compression_for_logging;
    }
  //std::cerr << __PRETTY_FUNCTION__ << " exit" << std::endl;
  return *this;
}

// --------------------------------------------/home/farges/work/ros-addons/proteus/TALCVideo/src/Image.cpp:466:39:---------------------------------
//
//
// -----------------------------------------------------------------------------
void Image::init(double ts, unsigned width, unsigned height, bool color, const unsigned char *data)
{
  //std::cerr << __PRETTY_FUNCTION__ << " enter" << std::endl;

  // de-allocate if different width/height/color
  if((m_pnm_image != 0) && 
     ((m_width  != width)  ||
      (m_height != height) ||
      (m_color  != color)))
    {
      //std::cerr << __PRETTY_FUNCTION__ << " delete" << std::endl;
      delete [] m_rows;
      m_rows = 0;
      m_pixels = 0;
      delete [] m_pnm_image;
      m_pnm_image = 0;
    }

  // setup width/height/color
  m_ts     = ts;
  m_width  = width;
  m_height = height;
  m_color  = color;

  if((sizeofPixels() != 0))
    {
      // realloc the image buffer
      if(m_pnm_image == 0)
        {
          //std::cerr << __PRETTY_FUNCTION__ << " new m_buffer" << std::endl;
          m_pnm_image = new unsigned char [sizeofPnm()];
        }

      // rebuild the pnm header
      snprintf((char *)m_pnm_image, m_pnm_image_header_size, "%s\n%u %u\n# %*c", getColor()?"P6":"P5", getWidth(), getHeight(), m_pnm_image_header_size, '-');

      m_pnm_image[m_pnm_image_header_size - 5] = '\n';
      m_pnm_image[m_pnm_image_header_size - 4] = '2';
      m_pnm_image[m_pnm_image_header_size - 3] = '5';
      m_pnm_image[m_pnm_image_header_size - 2] = '5';
      m_pnm_image[m_pnm_image_header_size - 1] = '\n';

      m_pixels = m_pnm_image + m_pnm_image_header_size;

      // copy the raw data
      if(data)
        {
          memcpy(m_pixels, data, sizeofPixels());
        }

      // rebuild the row representation
      if(m_rows == 0)
        {
          //std::cerr << __PRETTY_FUNCTION__ << " new m_rows" << std::endl;
          m_rows = new unsigned char * [m_height];
          for(unsigned i = 0; i < m_height; i++)
            {
              m_rows[i] = &m_pixels[i * m_width * getDepth()];
            }
        }
    }
  //std::cerr << __PRETTY_FUNCTION__ << " exit" << std::endl;
}

// -----------------------------------------------------------------------------
//
//
//
// -----------------------------------------------------------------------------
struct Heap
{
  Heap(uint8_t *buffer, unsigned size) :
    m_size(size),
    m_mem(buffer),
    m_usage(0)
  {
  }
  
  const unsigned   m_size;
  unsigned char *  m_mem;
  mutable unsigned m_usage;
};


static png_voidp png_cb_alloc(png_structp png_ptr, png_size_t size)
{
  Heap *libpng_heap = (Heap *)png_get_mem_ptr(png_ptr);
  png_voidp result = NULL;
  if(libpng_heap->m_usage + size < libpng_heap->m_size)
    {
      result = libpng_heap->m_mem + libpng_heap->m_usage;
      libpng_heap->m_usage += size;
    }
  else
    {
     png_error(png_ptr, "Heap full");
    }
  return result;
}

static void png_cb_free(png_structp png_ptr, png_voidp ptr)
{
  Heap *libpng_heap = (Heap *)png_get_mem_ptr(png_ptr);
  if(libpng_heap->m_mem == ptr)
    {
      libpng_heap->m_usage = 0;
    }
}

static void png_cb_write_data(png_structp png_ptr, png_bytep data, png_size_t length)
{
  Heap *io_heap = (Heap *)png_get_io_ptr(png_ptr);
  if(io_heap->m_usage + length < io_heap->m_size)
    {
      memcpy(io_heap->m_mem + io_heap->m_usage, data, length);
      io_heap->m_usage += length;
    }
  else
    {
     png_error(png_ptr, "Io buffer full");
    }
}

static void png_cb_read_data(png_structp png_ptr, png_bytep data, png_size_t length)
{
  Heap *io_heap = (Heap *)png_get_io_ptr(png_ptr);
  if(io_heap->m_usage + length < io_heap->m_size)
    {
      memcpy(data, io_heap->m_mem + io_heap->m_usage, length);
      io_heap->m_usage += length;
    }
  else
    {
     png_error(png_ptr, "Io buffer empty");
    }
}

static void png_cb_flush_data(png_structp png_ptr)
{
}

static void png_cb_error(png_structp png_ptr, png_const_charp error_msg)
{
  bool *error_flag = (bool *)png_get_error_ptr(png_ptr);
  *error_flag = true;
  std::cerr << "Error : " << error_msg << std::endl;
}

static void png_cb_warning(png_structp png_ptr, png_const_charp warning_msg)
{
  std::cerr << "Warning : " << warning_msg << std::endl;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
int Image::store(uint8_t *buffer, unsigned sizeof_buffer, char * file_name, unsigned sizeof_file_name) const
{
  unsigned buffer_usage = 0;
  const char * ext = 0;

  if(sizeofPixels())
    {
      if((Z_BEST_SPEED <= m_compression_for_logging) && (m_compression_for_logging <= Z_BEST_COMPRESSION))
        {
          if(!m_libpng_heap_buffer)
            {
              m_libpng_heap_buffer = new unsigned char [m_libpng_heap_buffer_size];
            }
          Heap libpng_heap(m_libpng_heap_buffer, m_libpng_heap_buffer_size); 
          Heap io_heap(buffer, sizeof_buffer);

          /* compression */
      
          /* init heap */
          libpng_heap.m_usage = 0;
      
          /* init png write structure */
          bool error_flag = false;
          png_structp png_ptr = png_create_write_struct_2(PNG_LIBPNG_VER_STRING, 
                                                          (png_voidp)&error_flag, 
                                                          png_cb_error, 
                                                          png_cb_warning,
                                                          (png_voidp)&libpng_heap,
                                                          png_cb_alloc, 
                                                          png_cb_free);
          if (!png_ptr) 
            {
              std::cerr << __PRETTY_FUNCTION__ << "png_create_write_struct_2 failed" << std::endl;
              return -1;
            }

          /* init png info structure */
          png_infop info_ptr = png_create_info_struct(png_ptr);
          if (!info_ptr)
            {
              std::cerr << __PRETTY_FUNCTION__ << "png_create_info_struct failed" << std::endl;
              return -1;
            }

          /* set png write functions */
          png_set_write_fn(png_ptr,
                           (png_voidp)&io_heap, 
                           png_cb_write_data,
                           png_cb_flush_data);

          /* set png filter and compression */
          png_set_filter(png_ptr, PNG_FILTER_TYPE_BASE, PNG_FILTER_PAETH);
          png_set_compression_strategy(png_ptr, Z_FILTERED);
          png_set_compression_level(png_ptr, m_compression_for_logging);

          /* set png IHDR chunk */
          png_set_IHDR(png_ptr, info_ptr, 
                       getWidth(), getHeight(),
                       8, (getColor())?PNG_COLOR_TYPE_RGB:PNG_COLOR_TYPE_GRAY, 
                       PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);

          /* set row pointers */
          png_set_rows(png_ptr, info_ptr, const_cast<unsigned char **>(getRows()));

          /* write png */
          png_write_png(png_ptr, info_ptr, PNG_TRANSFORM_IDENTITY, NULL);

          /* destroy structs */
          png_destroy_write_struct(&png_ptr, &info_ptr);

          /* check if some errors happen */
          if(error_flag)
            {
              std::cerr << __PRETTY_FUNCTION__ << "some error happen" << std::endl;
              return -1;
            }
  
          /* */
          assert(libpng_heap.m_usage == 0);

          buffer_usage = io_heap.m_usage;
          ext = "png";
        }
      else
        {
          /* or no compression */

          if(sizeof_buffer < sizeofPnm())
            {
              return -1;
            }

          memcpy(buffer, getPnm(), sizeofPnm()); 

          buffer_usage = sizeofPnm();

          ext = getColor()?"ppm":"pgm";
        }

      snprintf(file_name, sizeof_file_name, "%.9lf.%s", getTs(), ext);
    }

  return buffer_usage;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
int Image::load(const uint8_t *buffer, unsigned sizeof_buffer, const char * file_name, unsigned sizeof_file_name)
{
  // get timestamp
  double ts;
  if(file_name)
    {
      sscanf(file_name, "%lf", &ts);
    }
  else
    {
      ts = getTs();
    }

  if(!png_sig_cmp((png_byte *)buffer, 0, 8))
    {
      /* have a png file */

      if(!m_libpng_heap_buffer)
        {
          m_libpng_heap_buffer = new unsigned char [m_libpng_heap_buffer_size];
        }
      Heap libpng_heap(m_libpng_heap_buffer, m_libpng_heap_buffer_size); 
      Heap io_heap(const_cast<uint8_t *>(buffer), sizeof_buffer);

      /* decompression */
      
      /* init heap */
      libpng_heap.m_usage = 0;
      
      /* init png read structure */
      bool error_flag = false;
      png_structp png_ptr = png_create_read_struct_2(PNG_LIBPNG_VER_STRING, 
                                                     (png_voidp)&error_flag, 
                                                     png_cb_error, 
                                                     png_cb_warning,
                                                     (png_voidp)&libpng_heap,
                                                     png_cb_alloc, 
                                                     png_cb_free);
      if (!png_ptr) 
        {
          std::cerr << __PRETTY_FUNCTION__ << "png_create_write_struct_2 failed" << std::endl;
          return -1;
        }

      /* init png info structure */
      png_infop info_ptr = png_create_info_struct(png_ptr);
      if (!info_ptr)
        {
          std::cerr << __PRETTY_FUNCTION__ << "png_create_info_struct failed" << std::endl;
          return -1;
        }

      /* set png read functions */
      png_set_read_fn(png_ptr,
                      (png_voidp)&io_heap, 
                      png_cb_read_data);

      /* read png header */
      png_read_info(png_ptr, info_ptr);

      /* init image */
      assert(png_get_bit_depth(png_ptr, info_ptr) == 8);
      init(ts, 
           png_get_image_width(png_ptr, info_ptr), 
           png_get_image_height(png_ptr, info_ptr),
           (png_get_color_type(png_ptr, info_ptr) == PNG_COLOR_TYPE_GRAY)?false:true);

      /* read buffer */
      png_read_image(png_ptr, getRows());

      /* destroy structs */
      png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

      /* check if some errors happen */
      if(error_flag)
        {
          std::cerr << __PRETTY_FUNCTION__ << "some error happen" << std::endl;
          return -1;
        }
  
      /* */
      assert(libpng_heap.m_usage == 0);
    }
  else if((buffer[0] == 'P') && ((buffer[1] == '5') || (buffer[0] == '6')))
    {
      /* have a pnm file */

      const char *buffer_ptr = (const char *)buffer;

      // read the type of pnm
      bool color = (buffer_ptr[1] == '6');
      buffer_ptr += strcspn(buffer_ptr, " \n");
      buffer_ptr += strspn(buffer_ptr, " \n");

      // read the width
      unsigned width = atoi(buffer_ptr);
      buffer_ptr += strcspn(buffer_ptr, " \n");
      buffer_ptr += strspn(buffer_ptr, " \n");

      // read the height
      unsigned height = atoi(buffer_ptr);
      buffer_ptr += strcspn(buffer_ptr, " \n");
      buffer_ptr += strspn(buffer_ptr, " \n");

      // read the level
      //unsigned nb_levels = atoi(buffer_ptr);
      buffer_ptr += strcspn(buffer_ptr, " \n");
      buffer_ptr += strspn(buffer_ptr, " \n");

      // read the data
      init(ts, width, height, color, (const uint8_t *)buffer_ptr);
    }
  else
    {
      std::cerr << __PRETTY_FUNCTION__ << "image format not recognized" << std::endl;
      return -1;
    }
  return 0;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::ostream& Talc::Video::operator<<(std::ostream& os, const Image& img)
{
  std::stringstream ss;
  ss.setf(std::ios_base::fixed, std::ios_base::floatfield);
  ss << 
    img.getTs() << " (" <<
    img.getWidth() << "x" <<
    img.getHeight() << "x" <<
    img.getDepth() << ")";
  os << ss.str();
  return os;
}

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
std::istream& Talc::Video::operator>>(std::istream& is, Image& img)
{
  assert( 0 );
  return is;
}
