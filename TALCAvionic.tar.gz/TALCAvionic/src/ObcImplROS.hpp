#ifndef __talc_avionique_ObcImplROS_hpp__
#define __talc_avionique_ObcImplROS_hpp__

#include <climits> // on ne peut pas utiliser std::numeric_limits a l'init

#include "ObcInterface.hpp"
  
namespace Talc
{
  namespace Avionique
  {
    struct ObcImplROS : public ObcInterface
    {
      ObcImplROS(void);

      ~ObcImplROS(void);

      /////////////////////

      virtual bool init(State &state)
      {
        return false;
      }

      virtual void kill(void)
      {
      }

      virtual bool start(void)
      {
        return false;
      }

      virtual void stop(void)
      {
      }

      virtual int capture(State &state)
      {
        return -1;
      }

      virtual bool breakCapture(void)
      {
        return false;
      }

      /////////////////////

      virtual bool logState(const State& state); 

      bool getState(State& state, double date = -1) const;

      virtual bool setPhase(unsigned phase)
      {
        m_phase_cache = phase;
        m_phase_cache_ttl = m_phase_cache_ttl_max;
        return true;
      }

      bool setPhaseStr(const std::string& str)
      {
        int phase = 1; // Talc::Avionique::Phase::stringToPhase(str);
        if(0 <= phase)
          {
            return setPhase(1); // Talc::Avionique::Phase::stringToPhase(str));
          }
        else
          {
            return false;
          }
      }

      virtual bool setPhaseDescente(double altitude)
      {
        // c'est un peut tordu ici : on force ObcImpl::setPhase pour
        // ne pas descendre vers les implementation qui heritent de
        // cette classe.
        return ObcImplROS::setPhase(Talc::Avionique::Phase::Descente);
      }

      virtual unsigned getPhase(void) const
      {
        return m_phase_cache;
      }

      std::string getPhaseStr(void) const
      {
        return "bidon"; // Talc::Avionique::Phase::phaseToString(getPhase());
      }

      virtual bool move(double x, double y, double z, double psi)
      {
        return true;
      }

      virtual bool gotou(double x, double y, double z, double psi)
      {
        return true;
      }

      virtual bool track(double vx, double vy, double z, double psi)
      {
        return true;
      }

      virtual bool altitude(double altitude, bool enable)
      {
        return true;
      }

      virtual bool waypointAdd(Waypoint& wp); 

      virtual bool waypointDel(const Waypoint& wp) 
      {
        return true;
      }

      virtual bool wayAdd(Way& w);

      virtual bool wayDel(const Way& w)
      {
        return true;
      }

      virtual bool wayPush(Way& w); 

      virtual bool wayPop(void)
      {
        return true;
      }

      virtual bool obstacleAdd(Obstacle& obst);

      virtual bool obstacleDel(const Obstacle& obst)
      {
        return true;
      }

      virtual bool setObj(const Way& w, const Waypoint& wp)
      {
        return true;
      }

      bool quickWaypointDel(unsigned wp_id) 
      {
        Waypoint wp = {0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        wp.m_id = wp_id;
        return waypointDel(wp);
      }

      bool quickSetObj(unsigned w_id, unsigned wp_id) 
      {
        Way w = {0,0,0,0,0};
        w.m_id = w_id;
        Waypoint wp = {0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        wp.m_id = wp_id;
        return setObj(w, wp);
      }

      virtual double getMinDt(void)
      {
        return 0.025;
      }

      virtual double getMaxV(void)
      {
        return 8;
      }

      virtual double getMaxA(void)
      {
        return 0.8;
      }


      /////////////////////

    private:

      // a ring buffer of states
      static const unsigned m_log_states_cnt_max = 64;
      State               * m_log_states;
      volatile unsigned     m_log_states_wr_idx;
      unsigned              m_log_states_cnt;

      // counter for managing error messages
      mutable unsigned      m_err_cnt_no_state;
      mutable unsigned      m_err_cnt_more_than_last;
      mutable unsigned      m_err_cnt_less_than_first;

      // emulation de la perte de GPS
      double                m_lost_gps_time;

      // mise en cache de la phase pour contourner le retard
      // eventuel de mise a jour de la phase dans les trames d'etat
      unsigned              m_phase_cache;
      unsigned              m_phase_cache_ttl;
      unsigned              m_phase_cache_ttl_max;

      // gestion des index de waypoint, de way et d'obstacles 
public:
      unsigned              m_wp_id;
      unsigned              m_w_id;
      unsigned              m_obst_id;
      std::vector<Waypoint> wplist;
    };
  }
}

#endif /* define __talc_avionique_ObcImplROS_hpp__ */
