#include <cstring>
#include <cassert>
#include <limits>

#include "ObcImplROS.hpp"

using namespace Talc::Avionique;

// -----------------------------------------------------------------------------
//
//
// -----------------------------------------------------------------------------
ObcImplROS::ObcImplROS()
{
  // interface default settings
  // FIXME ce serait peut-etre plus clean de systematiquement
  // mettre ces init dans les sous classes les plus derivees
  m_rx_path         = "/dev/ttyS1";
  m_tx_path         = "/dev/ttyS2";
  m_origin[0]       = 0;
  m_origin[1]       = 0;
  m_origin[2]       = 0;
  m_enable_tx       = true;
  m_have_gps        = true;
  m_manage_wp_ids   = true;
  m_wp_id_min       = 50;
  m_wp_id_max       = 0x7FFF;
  m_manage_w_ids    = true;
  m_w_id_min        = 50;
  m_w_id_max        = 0x7FFF;
  m_manage_obst_ids = true;
  m_obst_id_min     = 50;
  m_obst_id_max     = 0x7FFF;
  
  // private implementation
  assert((m_log_states_cnt_max & (m_log_states_cnt_max - 1)) == 0);
  m_log_states = new State[m_log_states_cnt_max];
  m_log_states_wr_idx = 0;
  m_log_states_cnt = 0;

  m_err_cnt_no_state = 0;
  m_err_cnt_more_than_last = 0;
  m_err_cnt_less_than_first = 0;

  m_lost_gps_time = 0;

  m_phase_cache = 0;
  m_phase_cache_ttl = 100;
  m_phase_cache_ttl_max = 100;

  m_wp_id   = m_wp_id_min;
  m_w_id    = m_w_id_min;
  m_obst_id = m_obst_id_min;
}
 
// -----------------------------------------------------------------------------
//
// 
//
// -----------------------------------------------------------------------------
ObcImplROS::~ObcImplROS(void) 
{
  delete [] m_log_states;
}

// -----------------------------------------------------------------------------
//
// 
//
// -----------------------------------------------------------------------------
bool ObcImplROS::logState(const State& state) 
{
  unsigned prev_state_idx = (m_log_states_cnt_max + m_log_states_wr_idx - 1) % m_log_states_cnt_max;
  unsigned next_state_idx = (m_log_states_cnt_max + m_log_states_wr_idx + 1) % m_log_states_cnt_max;

  // on ne gere l'insertion d'un nouvel etat que si c'est un etat 
  // plus recent.
  if(m_log_states[prev_state_idx].m_ts < state.m_ts)
    {
      // insertion de l'etat dans le ring buffer.
      m_log_states[m_log_states_wr_idx] = state;

      // on va patcher l'etat du ring buffer pour notre
      // sauce interne (retard de la maj de la phase et 
      // emulation de la perte de gps).
      State& patched_state = m_log_states[m_log_states_wr_idx];

      // emulation de la perte de GPS
      if(!m_have_gps)
        {
          if(!m_lost_gps_time)
            {
              m_lost_gps_time = state.m_ts;
            }
          else
            {
              patched_state.m_gps_int_time = state.m_ts - m_lost_gps_time;
            }
        }
      else
        {
          m_lost_gps_time = 0;
        }

      // compensensation d'un eventuel retard de la maj 
      // de la phase par rapport aux trames obc.
      switch(m_phase_cache_ttl)
        {
        case UINT_MAX :
          // cas special ou on utilise toujours le cache et 
          // jamais la phase de l'etat recu.
          patched_state.m_phase = m_phase_cache;
          break;
        case 0 :
          if(m_enable_tx)
            {
              // cas ou le ttl du cache est ecoule, on recopie 
              // dans le cache la phase de l'etat recu.
              m_phase_cache = state.m_phase;
            }
          // si le tx n'est pas actif les changement de phases
          // ne seront pas pris en compte donc on emule le 
          // changement grace au cache.
          break;
        default :
          // cas ou le ttl du cache est en cours, on utilise
          // le cache
          patched_state.m_phase = m_phase_cache;
          m_phase_cache_ttl--;
          break; 
        }

      // increment de l'indice du ring buffer
      m_log_states_wr_idx = next_state_idx;
      if(m_log_states_cnt < m_log_states_cnt_max)
        {
          m_log_states_cnt++;
        }

      return true;
    }
  else
    {
      /*
        fprintf(stderr, "%s %d not implemented.\n", __PRETTY_FUNCTION__, __LINE__);
        assert(0);
      */
      return false;
    }
}

// -----------------------------------------------------------------------------
//
// 
//
// -----------------------------------------------------------------------------
bool ObcImplROS::getState(State& state, double date) const
{
  static const double extrapolation_limit = 0.2;

  // the index of the current state (attention m_log_states_wr_idx is a write idx)
  unsigned idx = (m_log_states_cnt_max + m_log_states_wr_idx - 1) % m_log_states_cnt_max;

  if(!m_log_states_cnt)
    {
      state.m_ts_ref = State::badRefSup;
      m_err_cnt_no_state++;
    }
  else if((m_log_states[idx].m_ts + extrapolation_limit) < date)
    {
      state.m_ts_ref = State::badRefSup;
      m_err_cnt_more_than_last++;
    }
  else if(m_log_states[idx].m_ts < date)
    {
      double dt = date - m_log_states[idx].m_ts;
      // state extrapolation
      state.m_ts_ref       = m_log_states[idx].m_ts;
      state.m_ts           = date;
      state.m_ts_remote    = m_log_states[idx].m_ts_remote + dt;    
      state.m_phase        = getPhase(); // get the cached phase    
      state.m_wp           = m_log_states[idx].m_wp;           
      state.m_cpt          = m_log_states[idx].m_cpt;           
      state.m_h_int_time   = m_log_states[idx].m_h_int_time?(m_log_states[idx].m_h_int_time + dt):0;   
      state.m_h            = m_log_states[idx].m_h;  
      state.m_gps_int_time = m_log_states[idx].m_gps_int_time?(m_log_states[idx].m_gps_int_time + dt):0; 
      state.m_pos[0]       = m_log_states[idx].m_pos[0] + m_log_states[idx].m_vel[0] * dt;
      state.m_pos[1]       = m_log_states[idx].m_pos[1] + m_log_states[idx].m_vel[1] * dt;
      state.m_pos[2]       = m_log_states[idx].m_pos[2] + m_log_states[idx].m_vel[2] * dt;
//      state.m_att          = m_log_states[idx].m_att;          
//      state.m_vel          = m_log_states[idx].m_vel;          
//      state.m_acc          = m_log_states[idx].m_acc;
    }
  else if((m_log_states[idx].m_ts == date) || (date < 0))
    {
      // get the latest state
      state = m_log_states[idx];
      state.m_ts_ref = m_log_states[idx].m_ts;
      // get the cached phase
      state.m_phase  = getPhase();             
    }
  else
    {
      // we go back in the past
      // the (idx != ((m_log_states_cnt_max + m_log_states_wr_idx + 1) % m_log_states_cnt_max)) condition
      // keep 2 log states. So the old state should not be corrupted by a new state
      // theoricaly it's not robust but in practice, the interpolation code should not take too 
      // long, so it's ok.
      unsigned idx_inf = (m_log_states_cnt_max + m_log_states_wr_idx - 2) % m_log_states_cnt_max;
      unsigned idx_sup = (m_log_states_cnt_max + m_log_states_wr_idx - 1) % m_log_states_cnt_max;
      unsigned idx_err = (m_log_states_cnt_max + m_log_states_wr_idx + 1) % m_log_states_cnt_max;
      while((idx_inf != idx_err) && (date < m_log_states[idx_inf].m_ts))
        {
          idx_sup = idx_inf;
          idx_inf = (m_log_states_cnt_max + idx_inf - 1) % m_log_states_cnt_max;
          idx_err = (m_log_states_cnt_max + m_log_states_wr_idx + 1) % m_log_states_cnt_max;
        } 

      if(idx_inf == idx_err)
        {
          // error : too far in the past
          state.m_ts_ref = State::badRefInf;
          m_err_cnt_less_than_first++;
        }
      else
        {
          // we have found the interval betwen idx_inf and idx_sup
          double dt = date - m_log_states[idx_inf].m_ts;
          double coef = dt / (m_log_states[idx_sup].m_ts - m_log_states[idx_inf].m_ts);

          // use the cached phase if not too far in the past
          unsigned phase;
          if(idx_sup == idx)
            {
              phase = getPhase();
            }
          else
            {
              phase = m_log_states[idx_inf].m_phase;
            }

          // state interpolation
          state.m_ts_ref       = m_log_states[idx_sup].m_ts;
          state.m_ts           = date;           
          state.m_ts_remote    = m_log_states[idx_inf].m_ts_remote + dt;
          state.m_phase        = phase;
          state.m_wp           = m_log_states[idx_inf].m_wp;           
          state.m_cpt          = m_log_states[idx_inf].m_cpt;           
          state.m_h_int_time   = m_log_states[idx_inf].m_h_int_time?(m_log_states[idx_inf].m_h_int_time + dt):0;   
          state.m_h            = m_log_states[idx_inf].m_h + (m_log_states[idx_sup].m_h - m_log_states[idx_inf].m_h) * coef;  
         
          state.m_gps_int_time = m_log_states[idx_inf].m_gps_int_time?(m_log_states[idx_inf].m_gps_int_time + dt):0; 
          for(unsigned j = 0; j < 3; j++)
            {
              state.m_pos[j]   = m_log_states[idx_inf].m_pos[j] + (m_log_states[idx_sup].m_pos[j] - m_log_states[idx_inf].m_pos[j]) * coef;
              state.m_att[j]   = m_log_states[idx_inf].m_att[j] + (m_log_states[idx_sup].m_att[j] - m_log_states[idx_inf].m_att[j]) * coef;          
              state.m_vel[j]   = m_log_states[idx_inf].m_vel[j] + (m_log_states[idx_sup].m_vel[j] - m_log_states[idx_inf].m_vel[j]) * coef;          
              state.m_acc[j]   = m_log_states[idx_inf].m_acc[j] + (m_log_states[idx_sup].m_acc[j] - m_log_states[idx_inf].m_acc[j]) * coef;          
            }
        }
    }

  // manage error printing
  if(state.badRef())
    {
      if(m_err_cnt_no_state == 1)
        {
//          fprintf(stderr, "no state available\n");
        }
      if(m_err_cnt_more_than_last == 1)
        {
//          fprintf(stderr, "%.3f is more than %f of the last state (%.3f)\n", date, extrapolation_limit, m_log_states[idx].m_ts);
        }
      if(m_err_cnt_less_than_first == 1)
        {
//          fprintf(stderr, "%.3f is less than the oldest state\n", date);
        }
    }
  else
    {
      if(1 < m_err_cnt_no_state)
        {
//          fprintf(stderr, "no state available repeated %d times\n", m_err_cnt_no_state);
          m_err_cnt_no_state = 0;
        }
      if(1 < m_err_cnt_more_than_last)
        {
//          fprintf(stderr, "more than %f of the last state repeated %d times\n", extrapolation_limit, m_err_cnt_more_than_last);
          m_err_cnt_more_than_last = 0;
        }
      if(1 < m_err_cnt_less_than_first)
        {
 //         fprintf(stderr, "less than the oldest state repeated %d times\n", m_err_cnt_less_than_first);
          m_err_cnt_less_than_first = 0;
        }
    }

  // return the ref id
  return !state.badRef();
}

// -----------------------------------------------------------------------------
//
// 
//
// -----------------------------------------------------------------------------
bool ObcImplROS::waypointAdd(Waypoint& wp)
{
  if(m_manage_wp_ids)
    {
      // attention, ici, comme dans presque toutes les fonctions
      // de ce fichier, on n'est pas reentrant !!!!!
      // tout cela n'etant pas atomique c'est suceptible de poser probleme
      wp.m_id = m_wp_id;
      m_wp_id++;
      if(m_wp_id_max <= m_wp_id)
        {
          m_wp_id = m_wp_id_min;
        }
    }
  wplist.push_back(wp);
  return true;

} 

// -----------------------------------------------------------------------------
//
// 
//
// -----------------------------------------------------------------------------
bool ObcImplROS::wayAdd(Way& w)
{
  if(m_manage_w_ids)
    {
      // attention, ici, comme dans presque toutes les fonctions
      // de ce fichier, on n'est pas reentrant !!!!!
      // tout cela n'etant pas atomique c'est suceptible de poser probleme
      w.m_id = m_w_id;
      m_w_id++;
      if(m_w_id_max <= m_w_id)
        {
          m_w_id = m_w_id_min;
        }
    }
  return true;
}

// -----------------------------------------------------------------------------
//
// 
//
// -----------------------------------------------------------------------------
bool ObcImplROS::wayPush(Way& w)
{
  if(m_manage_w_ids)
    {
      // attention, ici, comme dans presque toutes les fonctions
      // de ce fichier, on n'est pas reentrant !!!!!
      // tout cela n'etant pas atomique c'est suceptible de poser probleme
      w.m_id = m_w_id;
      m_w_id++;
      if(m_w_id_max <= m_w_id)
        {
          m_w_id = m_w_id_min;
        }
    }
  return true;
}

// -----------------------------------------------------------------------------
//
// 
//
// -----------------------------------------------------------------------------
bool ObcImplROS::obstacleAdd(Obstacle& obst)
{
  if(m_manage_obst_ids)
    {
      // attention, ici, comme dans presque toutes les fonctions
      // de ce fichier, on n'est pas reentrant !!!!!
      // tout cela n'etant pas atomique c'est suceptible de poser probleme
      obst.m_id = m_obst_id;
      m_obst_id++;
      if(m_obst_id_max <= m_obst_id)
        {
          m_obst_id = m_obst_id_min;
        }
    }
  return true;
}

