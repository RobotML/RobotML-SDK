#ifndef __talc_avionique_Obstacle_hpp__
#define __talc_avionique_Obstacle_hpp__

#include <vector>
// #include <array>
#include <iostream>

namespace Talc
{
  namespace Avionique
  {
    struct Obstacle
    {
      unsigned m_id; 
      double   m_radius;
//      std::vector<std::array<double, 3> > m_vertex;
      double m_vertex[3];
    };

    std::ostream& operator<<(std::ostream& os, const Obstacle& way);

    std::istream& operator>>(std::istream& is, Obstacle& way);
  }
}


#endif /* __talc_avionique_Obstacle_hpp__ */
